#!/usr/bin/python3
# auther@hy
# 2022年06月09日
def receive():
    return "接受信息......"