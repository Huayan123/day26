#!/usr/bin/python3
# auther@hy
# 2022年06月09日
def send():
    print("发送信息......")